module.exports = Ferdi => class Odoo extends Ferdi {};
