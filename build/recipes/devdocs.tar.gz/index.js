module.exports = Ferdi => class devdocs extends Ferdi {};
