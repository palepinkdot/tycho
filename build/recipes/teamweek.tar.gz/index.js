module.exports = Ferdi => class Teamweek extends Ferdi {};
