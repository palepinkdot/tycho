window.electronSafeIpc = {
  send: () => null,
  on: () => null,
};
window.desktop = undefined;
