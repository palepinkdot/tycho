module.exports = (Ferdi) => class LineMe extends Ferdi {};
