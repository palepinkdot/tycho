module.exports = Ferdi => class Tinder extends Ferdi {};
