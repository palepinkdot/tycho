// todo allow custom url
module.exports = Ferdi => class HackMd extends Ferdi {};
