module.exports = Ferdi => class AmazonWebServices extends Ferdi {};
