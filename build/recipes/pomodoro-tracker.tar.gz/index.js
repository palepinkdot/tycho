module.exports = Ferdi => class pomodorotracker extends Ferdi {};
