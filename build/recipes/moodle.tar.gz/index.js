module.exports = Ferdi => class moodle extends Ferdi {};
