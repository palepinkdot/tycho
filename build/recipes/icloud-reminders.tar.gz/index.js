module.exports = Ferdi => class icloudreminders extends Ferdi {};
