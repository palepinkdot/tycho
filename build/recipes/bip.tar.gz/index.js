module.exports = Ferdi => class bip extends Ferdi {};
