module.exports = Ferdi => class pinterest extends Ferdi {};
