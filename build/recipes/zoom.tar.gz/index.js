"use strict";
module.exports = Ferdi => Ferdi
