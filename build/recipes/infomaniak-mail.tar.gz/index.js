module.exports = Ferdi => class infomaniakmail extends Ferdi {};
