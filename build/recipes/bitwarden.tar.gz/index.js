module.exports = Ferdi => class Bitwarden extends Ferdi {};
