module.exports = Ferdi => class Meetup extends Ferdi {};
