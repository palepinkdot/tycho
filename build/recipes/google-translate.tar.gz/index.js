module.exports = Ferdi => class GoogleTranslate extends Ferdi {};
