"use strict";

// just pass through ferdi

module.exports = Ferdi => Ferdi;