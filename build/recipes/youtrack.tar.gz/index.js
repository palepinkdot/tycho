module.exports = Ferdi => class youtrack extends Ferdi {};
