module.exports = Ferdi => class stackoverflowchat extends Ferdi {};
