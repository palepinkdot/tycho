module.exports = Ferdi => class GoogleKeep extends Ferdi {};
