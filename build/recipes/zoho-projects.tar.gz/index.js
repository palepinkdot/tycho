module.exports = Ferdi => class ZohoProjects extends Ferdi {};
