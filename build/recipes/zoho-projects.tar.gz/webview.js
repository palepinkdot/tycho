module.exports = () => {
  // TODO: If your Zoho Projects service has unread messages, uncomment these lines to implement the logic for updating the badges
  // const getMessages = () => {
  //   // TODO: Insert your notification-finding code here
  //   Ferdi.setBadge(0, 0);
  // };
  // Ferdi.loop(getMessages);
};
