module.exports = Ferdi => class simplenote extends Ferdi {};
