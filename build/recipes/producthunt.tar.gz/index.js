module.exports = Ferdi => Ferdi
