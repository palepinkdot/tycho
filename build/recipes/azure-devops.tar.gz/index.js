module.exports = Ferdi => class azuredevops extends Ferdi {};
