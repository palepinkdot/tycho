module.exports = Ferdi => class onenote extends Ferdi {};
