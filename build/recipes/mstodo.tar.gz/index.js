module.exports = Ferdi => class mstodo extends Ferdi {};
