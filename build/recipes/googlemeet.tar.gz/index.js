module.exports = Ferdi => class GoogleMeet extends Ferdi {};
