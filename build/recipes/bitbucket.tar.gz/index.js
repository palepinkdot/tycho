module.exports = Ferdi => class bitbucket extends Ferdi {};
