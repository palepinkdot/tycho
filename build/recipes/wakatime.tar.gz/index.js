module.exports = Ferdi => class Wakatime extends Ferdi {};
