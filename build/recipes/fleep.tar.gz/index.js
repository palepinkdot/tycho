module.exports = Ferdi => class fleep extends Ferdi {};
