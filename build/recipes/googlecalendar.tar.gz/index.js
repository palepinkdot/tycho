module.exports = Ferdi => class GoogleCalendar extends Ferdi {};
