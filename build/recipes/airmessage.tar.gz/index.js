module.exports = Ferdi => class Airmessage extends Ferdi {};
