module.exports = (Ferdi) => class Hangouts extends Ferdi {};
