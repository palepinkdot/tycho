module.exports = Ferdi => class Workflowy extends Ferdi {};
