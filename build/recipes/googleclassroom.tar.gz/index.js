module.exports = Ferdi => class GoogleClassroom extends Ferdi {};
