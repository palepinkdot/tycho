module.exports = Ferdi => class Scribens extends Ferdi {};
