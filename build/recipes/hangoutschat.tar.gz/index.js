module.exports = Ferdi => class HangoutsChat extends Ferdi {};
