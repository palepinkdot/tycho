module.exports = (Ferdi) => class Netlify extends Ferdi {};
