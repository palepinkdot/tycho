module.exports = Ferdi => class figma extends Ferdi {};
