module.exports = Ferdi => class Hubstaff extends Ferdi {};
