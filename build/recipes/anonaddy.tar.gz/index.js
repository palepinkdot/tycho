module.exports = Ferdi => class anonaddy extends Ferdi {};
