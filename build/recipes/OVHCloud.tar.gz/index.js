module.exports = (Ferdi) => class OVHCloud extends Ferdi {};
