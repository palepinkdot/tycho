module.exports = Ferdi => class erepublik extends Ferdi {};
