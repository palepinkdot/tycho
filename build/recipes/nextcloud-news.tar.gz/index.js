module.exports = Ferdi => class NextcloudNews extends Ferdi {};
