module.exports = (Ferdi) => class DockerHub extends Ferdi {};
