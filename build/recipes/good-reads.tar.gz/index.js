module.exports = (Ferdi) => class GoodReads extends Ferdi {};
