module.exports = Ferdi => class Gmail extends Ferdi {};
