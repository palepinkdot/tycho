module.exports = Ferdi => class Freshdesk extends Ferdi {};
