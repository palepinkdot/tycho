module.exports = Ferdi => class GitHub extends Ferdi {};
