module.exports = Ferdi => class epicgames extends Ferdi {};
