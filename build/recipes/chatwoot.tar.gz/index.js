module.exports = (Ferdi) => Ferdi;
