module.exports = Ferdi => class Binance extends Ferdi {};
