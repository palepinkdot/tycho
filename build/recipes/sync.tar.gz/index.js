module.exports = Ferdi => class sync extends Ferdi {};
