module.exports = (Ferdi) => class Dropbox extends Ferdi {};
